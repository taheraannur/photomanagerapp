package com.blackdiamond.myapplication.dataClasses


data class Album(
    var folderName: String,
    var imagePaths: ArrayList<String>
)